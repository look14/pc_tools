CREATE TABLE Branding ( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),resource_type TEXT NOT NULL,resource_data TEXT NOT NULL,PRIMARY KEY (ProductID, resource_type) )
CREATE TABLE DependencyData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PayloadIDb TEXT ,type TEXT NOT NULL ,product_family TEXT, product_name TEXT, version TEXT, PRIMARY KEY (PayloadID,PayloadIDb,type,product_family,product_name,version))
CREATE TABLE EULA_Files( productID TEXT NOT NULL, langCode TEXT NOT NULL,eula TEXT NOT NULL,PRIMARY KEY (productID, langCode) )
CREATE TABLE PayloadData( PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),domain TEXT NOT NULL,key TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY (PayloadID, domain, key) )
CREATE TABLE Payloads( PayloadID TEXT NOT NULL, payload_family TEXT NOT NULL,payload_name TEXT NOT NULL, payload_version TEXT NOT NULL,payload_type TEXT NOT NULL,PRIMARY KEY (PayloadID) )
CREATE TABLE SuitePayloads( ProductID TEXT NOT NULL REFERENCES Suites (ProductID),PayloadID TEXT NOT NULL REFERENCES Payloads (PayloadID),PRIMARY KEY (ProductID, PayloadID) )
CREATE TABLE Suites( ProductID TEXT NOT NULL, group_name TEXT NOT NULL, group_family TEXT NOT NULL, display_name TEXT NOT NULL, PRIMARY KEY (ProductID) )
CREATE TABLE EULA_Ref( productID TEXT NOT NULL, langCode TEXT NOT NULL, eula_hash TEXT NOT NULL, PRIMARY KEY (productID, langCode) )
CREATE TABLE EULA_Content(eula_hash TEXT NOT NULL, Content TEXT NOT NULL, PRIMARY KEY (eula_hash))
CREATE TABLE IF NOT EXISTS pcd_meta ( key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY (key) )
INSERT OR REPLACE INTO pcd_meta (key, value) VALUES ('schema_version', 2)
INSERT OR REPLACE INTO pcd_meta (key, value) VALUES ('schema_compatibility_version', 1)
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0" , "ValidationInfo", '<ValidationInfo payloadID="{185F9795-9663-4F13-9EF9-307A282ADB5A}"/>')
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0" , "ValidationSig", "YjRf4YW0DzGj0OQGcVQdxCYTt0ERI0fcoFuY53DSHH+BZaRVi1mH2Ol+d8xwabhrXtxT6E0rVe4d3fa88I+/rQUSi2yXjX/KRs9sNvicNPfSupJpqfORddQ5Dqiv8u/+9z4+O7MbOlRl8Luc7sSc2W7CnDBFRnBoJV+rg4STfSWUv6aA8vT9gHPSEE5Cu5uMsnIQVGLK2ltzzqKyLFY05czTOxdTeU5BORjSNhS9ZQ46KzCIvXFyzuoOk4A/SMcpBefOiHmCj3bHaLN2ml3h5GMYM53OPE7l+bazOk+/5R/blHodDmCaYIqww7t3Xu6RIa5WFAVwus+lGxYcDng1Aj09ZniebffddnBQzp/S5XjLlYGi159bNfqFaPXsoWjHl8/yoN1LM/lL1U3STBvNu8r34W4V9AY0kHQlUBzSUznZ0wQlVIyQJFFR8D+VGfVRAI2JYBtYaCMW/mc35Y3nAMqzOf8R5FTUh5Os5hG1DITwNISk7MGX6udcpuLiPeON")
INSERT INTO Payloads VALUES	("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "NonAdobePayload", "SonicWrappers_ph", "6.0", "normal")
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0" , "PayloadInfo", '<PayloadInfo version="6.0.29.0"><BuildInfo>
    <Property name="Created">2012-01-13 15:59:12.480000</Property>
    <Property name="TargetName">SonicWrappers_ph6.0-mul</Property>
    <Property name="ProcessorFamily">All</Property>
  </BuildInfo><InstallerProperties>
    <Property name="payloadType">SQLite</Property>
    <Property name="AdobeCode">{185F9795-9663-4F13-9EF9-307A282ADB5A}</Property>
    <Property name="ProductName">SonicWrappers_ph</Property>
    <Property name="ProductVersion">6.0</Property>
  </InstallerProperties><InstallDir>
    <Platform isFixed="0" name="Default" folderName="">[AdobeProgramFiles]</Platform>
  </InstallDir><Languages languageIndependent="1"/><Satisfies>
    <ProductInfo>
		<Family>NonAdobePayload</Family>
		<ProductName>SonicWrappers_ph</ProductName>
	<ProductVersion>6.0</ProductVersion>
    </ProductInfo>
  </Satisfies><Channel enable="1" id="SonicWrappers_ph-6.0">
    <DisplayName>SonicWrappers_ph</DisplayName>
  </Channel><InstallDestinationMetadata relocatableSize="0" sysDriveSize="1436672">
    <Destination>
      <Root>[INSTALLDIR]</Root>
      <TotalSize>1436672</TotalSize>
      <MaxPathComponent>ph.msi</MaxPathComponent>
    </Destination>
    <Assets>
      <Asset flag="0" name="Assets2_1" size="1436672"/>
    </Assets>
  </InstallDestinationMetadata><ConflictingProcesses>
	<Win32>
	</Win32>
</ConflictingProcesses><AddRemoveInfo>
    <DisplayVersion>
      <Value lang="ar_AE">6.0</Value>
      <Value lang="be_BY">6.0</Value>
      <Value lang="bg_BG">6.0</Value>
      <Value lang="ca_ES">6.0</Value>
      <Value lang="cs_CZ">6.0</Value>
      <Value lang="da_DK">6.0</Value>
      <Value lang="de_DE">6.0</Value>
      <Value lang="el_GR">6.0</Value>
      <Value lang="en_GB">6.0</Value>
      <Value lang="en_MX">6.0</Value>
      <Value lang="en_US">6.0</Value>
      <Value lang="en_XC">6.0</Value>
      <Value lang="en_XM">6.0</Value>
      <Value lang="es_ES">6.0</Value>
      <Value lang="es_MX">6.0</Value>
      <Value lang="es_QM">6.0</Value>
      <Value lang="et_EE">6.0</Value>
      <Value lang="fi_FI">6.0</Value>
      <Value lang="fr_CA">6.0</Value>
      <Value lang="fr_FR">6.0</Value>
      <Value lang="fr_MX">6.0</Value>
      <Value lang="fr_XM">6.0</Value>
      <Value lang="he_IL">6.0</Value>
      <Value lang="hi_IN">6.0</Value>
      <Value lang="hr_HR">6.0</Value>
      <Value lang="hu_HU">6.0</Value>
      <Value lang="is_IS">6.0</Value>
      <Value lang="it_IT">6.0</Value>
      <Value lang="ja_JP">6.0</Value>
      <Value lang="ko_KR">6.0</Value>
      <Value lang="lt_LT">6.0</Value>
      <Value lang="lv_LV">6.0</Value>
      <Value lang="mk_MK">6.0</Value>
      <Value lang="nb_NO">6.0</Value>
      <Value lang="nl_NL">6.0</Value>
      <Value lang="nn_NO">6.0</Value>
      <Value lang="no_NO">6.0</Value>
      <Value lang="pl_PL">6.0</Value>
      <Value lang="pt_BR">6.0</Value>
      <Value lang="ro_RO">6.0</Value>
      <Value lang="ru_RU">6.0</Value>
      <Value lang="sh_YU">6.0</Value>
      <Value lang="sk_SK">6.0</Value>
      <Value lang="sl_SI">6.0</Value>
      <Value lang="sq_AL">6.0</Value>
      <Value lang="sv_SE">6.0</Value>
      <Value lang="th_TH">6.0</Value>
      <Value lang="tr_TR">6.0</Value>
      <Value lang="uk_UA">6.0</Value>
      <Value lang="vi_VN">6.0</Value>
      <Value lang="zh_CN">6.0</Value>
      <Value lang="zh_TW">6.0</Value>
      <Value lang="en_AE">6.0</Value>
      <Value lang="en_IL">6.0</Value>
      <Value lang="fr_MA">6.0</Value>
    </DisplayVersion>
    <DisplayName>
      <Value lang="ar_AE">SonicWrappers_ph</Value>
      <Value lang="be_BY">SonicWrappers_ph</Value>
      <Value lang="bg_BG">SonicWrappers_ph</Value>
      <Value lang="ca_ES">SonicWrappers_ph</Value>
      <Value lang="cs_CZ">SonicWrappers_ph</Value>
      <Value lang="da_DK">SonicWrappers_ph</Value>
      <Value lang="de_DE">SonicWrappers_ph</Value>
      <Value lang="el_GR">SonicWrappers_ph</Value>
      <Value lang="en_GB">SonicWrappers_ph</Value>
      <Value lang="en_MX">SonicWrappers_ph</Value>
      <Value lang="en_US">SonicWrappers_ph</Value>
      <Value lang="en_XC">SonicWrappers_ph</Value>
      <Value lang="en_XM">SonicWrappers_ph</Value>
      <Value lang="es_ES">SonicWrappers_ph</Value>
      <Value lang="es_MX">SonicWrappers_ph</Value>
      <Value lang="es_QM">SonicWrappers_ph</Value>
      <Value lang="et_EE">SonicWrappers_ph</Value>
      <Value lang="fi_FI">SonicWrappers_ph</Value>
      <Value lang="fr_CA">SonicWrappers_ph</Value>
      <Value lang="fr_FR">SonicWrappers_ph</Value>
      <Value lang="fr_MX">SonicWrappers_ph</Value>
      <Value lang="fr_XM">SonicWrappers_ph</Value>
      <Value lang="he_IL">SonicWrappers_ph</Value>
      <Value lang="hi_IN">SonicWrappers_ph</Value>
      <Value lang="hr_HR">SonicWrappers_ph</Value>
      <Value lang="hu_HU">SonicWrappers_ph</Value>
      <Value lang="is_IS">SonicWrappers_ph</Value>
      <Value lang="it_IT">SonicWrappers_ph</Value>
      <Value lang="ja_JP">SonicWrappers_ph</Value>
      <Value lang="ko_KR">SonicWrappers_ph</Value>
      <Value lang="lt_LT">SonicWrappers_ph</Value>
      <Value lang="lv_LV">SonicWrappers_ph</Value>
      <Value lang="mk_MK">SonicWrappers_ph</Value>
      <Value lang="nb_NO">SonicWrappers_ph</Value>
      <Value lang="nl_NL">SonicWrappers_ph</Value>
      <Value lang="nn_NO">SonicWrappers_ph</Value>
      <Value lang="no_NO">SonicWrappers_ph</Value>
      <Value lang="pl_PL">SonicWrappers_ph</Value>
      <Value lang="pt_BR">SonicWrappers_ph</Value>
      <Value lang="ro_RO">SonicWrappers_ph</Value>
      <Value lang="ru_RU">SonicWrappers_ph</Value>
      <Value lang="sh_YU">SonicWrappers_ph</Value>
      <Value lang="sk_SK">SonicWrappers_ph</Value>
      <Value lang="sl_SI">SonicWrappers_ph</Value>
      <Value lang="sq_AL">SonicWrappers_ph</Value>
      <Value lang="sv_SE">SonicWrappers_ph</Value>
      <Value lang="th_TH">SonicWrappers_ph</Value>
      <Value lang="tr_TR">SonicWrappers_ph</Value>
      <Value lang="uk_UA">SonicWrappers_ph</Value>
      <Value lang="vi_VN">SonicWrappers_ph</Value>
      <Value lang="zh_CN">SonicWrappers_ph</Value>
      <Value lang="zh_TW">SonicWrappers_ph</Value>
      <Value lang="en_AE">SonicWrappers_ph</Value>
      <Value lang="en_IL">SonicWrappers_ph</Value>
      <Value lang="fr_MA">SonicWrappers_ph</Value>
    </DisplayName>
  </AddRemoveInfo><UserPreferences>0</UserPreferences><ThirdPartyComponent modifierID="{FFDA32AB-6F9A-4307-B4F4-DC9F9DA7D173}">
							<Metadata>
								<Type>msiPackage</Type>
								<Name>ph.msi</Name>
								<Properties>
									<Property name="ProductCode">{185F9795-9663-4F13-9EF9-307A282ADB5A}</Property>
								</Properties>
							</Metadata>
							<Capabilities>
								<Install stringID="ph_install">
									<Value lang="en_US">ph installed</Value>
								</Install>
								<Repair isRepairable="1" stringID="ph_reinstall">
									<Value lang="en_US">ph reinstalled</Value>
								</Repair>
								<Uninstall stringID="ph_uninstall" isUninstallable="0">
									<Value lang="en_US">ph was uninstalled</Value>
								</Uninstall>
							</Capabilities>
						</ThirdPartyComponent></PayloadInfo>')
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0" , "WorkflowVersion", "CS6")
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0" , "DEVersion", "6.0")
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0", "ChannelID", "SonicWrappers_ph-6.0")
INSERT INTO PayloadData VALUES("{185F9795-9663-4F13-9EF9-307A282ADB5A}", "0", "ChannelInfo", '<Channel enable="1" id="SonicWrappers_ph-6.0">
    <DisplayName>SonicWrappers_ph</DisplayName>
  </Channel>')
